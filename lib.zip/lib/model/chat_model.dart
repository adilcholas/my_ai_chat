class ChatModel {
  String text;
  bool isUser;

  ChatModel({required this.text, required this.isUser});
}